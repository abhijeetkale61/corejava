package problemstatement9;

public class main {
	static void printFreq(int arr[], int N)
    {
 
        
        int freq = 1;
 
        
        for (int i = 1; i < N; i++) {
            
            if (arr[i] == arr[i - 1]) {
               
                freq++;
            }
 
            
            else {
                System.out.println(arr[i - 1]+" occurs "
                           + freq
                           + " times ");
               
                freq = 1;
            }
        }
 
        
        System.out.println( arr[N - 1]+" occurs "
                           + freq
                           + " times " );
    }
 
    
    public static void main(String args[])
    {
        
        int arr[]
            = { 2, 6, 6, 5, 4, 4, 2, 6,
                8, 10, 9, 10, 2, 6 };
        int N = arr.length;
 
        
        printFreq(arr, N);
    }

}

