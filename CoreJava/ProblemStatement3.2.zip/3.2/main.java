package statement;

public class medicine {
	public void displayLabel(){
		System.out.println("Company : chromax");
		System.out.println("Address : pune");
		}
		}
	class Tablet extends medicine{
		 
	public void displayLabel(){
		System.out.println("store away from sunglight");
		}
	}
	class Syrup extends medicine{
		public void displayLabel(){
		System.out.println("store away fro children");
		}
		}
	class Ointment extends medicine{
		public void displayLabel(){
		System.out.println("for external use only");
	}
	}

